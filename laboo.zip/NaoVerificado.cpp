#include "NaoVerificado.h"

NaoVerificado::NaoVerificado():logic_error("canal nao verificado") {}